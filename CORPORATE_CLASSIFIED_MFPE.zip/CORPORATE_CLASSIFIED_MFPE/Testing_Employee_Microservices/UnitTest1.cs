
using CLassifiedsUIPortal.Controllers;
using CLassifiedsUIPortal.Provider;
using EmployeeMicroservice.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace StockApiTesting
{
    public class Tests
    {
        List<Employee> employee = new List<Employee>();
        readonly EmployeeController employeeController;
        readonly EmployeeProvider employeeProvider;
        private readonly Mock<IEmployeeProvider> mockProvider = new Mock<IEmployeeProvider>();
        //private readonly Mock<IStockRepository> mockRepository = new Mock<IStockRepository>();

        public Tests()
        {
            employeeController = new EmployeeController(mockProvider.Object);
            //stockProvider = new StockProvider(mockRepository.Object);
        }


        [SetUp]
        public void Setup()
        {
            employee = new List<Employee>()
            {
                new Employee{ EmployeeId=101, EmployeeName="Lakshmi", Password="12345"},
                new Employee{ EmployeeId=102, EmployeeName="Sindhu",  Password="12345" }
            };

            mockProvider.Setup(x => x.GetEmployeeList(It.IsAny<string>())).Returns((string s) => employee.FirstOrDefault(
                x => x.EmployeeName.Equals(s)));

            // mockRepository.Setup(x => x.GetStockByNameRepository(It.IsAny<string>())).Returns((string s) => stocks.FirstOrDefault(
            // x => x.StockName.Equals(s)));
        }

        [Test]
        public void GetStockByNameController_PassCase()
        {
            var stock = stockController.GetStockByName("DUMMY");
            ObjectResult result = stock as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }

        [Test]
        public void GetStockByNameController_FailCase()
        {
            var stock = stockController.GetStockByName("ABC");
            ObjectResult result = stock as ObjectResult;
            Assert.AreEqual(404, result.StatusCode);
        }

        [Test]
        public void GetStockByNameProvider_PassCase()
        {
            var stock = stockProvider.GetStockByNameProvider("DUMMY");
            Assert.IsNotNull(stock);
        }

        [Test]
        public void GetStockByNameProvider_FailCase()
        {
            var stock = stockProvider.GetStockByNameProvider("ABC");
            Assert.IsNull(stock);
        }

    }
}