﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CLassifiedsUIPortal.Models
{
    public class EmployeeData
    {
        public int EmployeeId { get; set; }


        public string EmployeeName { get; set; }


        public string Password { get; set; }

        public int TotalPoints { get; set; }
    }
}
