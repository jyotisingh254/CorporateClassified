﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CLassifiedsUIPortal.Models
{
    public class PointsData
    {
        //public int PointId { get; set; }

        public int EmployeeId { get; set; }

        public int TotalPoints { get; set; }
    }
}
