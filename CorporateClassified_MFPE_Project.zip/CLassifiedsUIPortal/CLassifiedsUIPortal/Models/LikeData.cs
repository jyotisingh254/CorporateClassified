﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CLassifiedsUIPortal.Models
{
    public class LikeData
    {
        public int LikeId { get; set; }

        public int OfferId { get; set; }

        public DateTime LikeDate { get; set; }
    }
}
