﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointsMicroservice.Models
{
    public class Points
    {
       // public int PointId { get; set; }

        public int EmployeeId { get; set; }

        public int TotalPoints { get; set; }


    }
}
